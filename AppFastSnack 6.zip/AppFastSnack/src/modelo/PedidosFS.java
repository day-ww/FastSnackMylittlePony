/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modelo;

import java.time.format.DateTimeFormatter;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;

/**
 *
 * @author USER
 */
public class PedidosFS extends javax.swing.JFrame {

    private TableRowSorter<DefaultTableModel> sorter;

    public PedidosFS() {
        initComponents();

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID Pedido", "Fecha", "Cliente", "Total", "Estado"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTablePedidos.setModel(modelo);
        jTablePedidos.getTableHeader().setReorderingAllowed(false);
        jTablePedidos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        sorter = new TableRowSorter<>(modelo);
        jTablePedidos.setRowSorter(sorter);

        // Conectar búsqueda
        jTextBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                filtrar();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                filtrar();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                filtrar();
            }

            private void filtrar() {
                String texto = jTextBuscar.getText();
                if (texto.trim().length() == 0) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
                }
            }
        });

        cargarPedidos();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePedidos = new javax.swing.JTable();
        btnVerDetalle = new javax.swing.JButton();
        jButtonCambiarEstado = new javax.swing.JButton();
        jButtonAgregarPedido = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextBuscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logo.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 244, 231));

        jTablePedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID pedido", "Fecha", "Cliente", "Total ", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTablePedidos);

        btnVerDetalle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/detalle.png"))); // NOI18N
        btnVerDetalle.setText("Ver Detalle");
        btnVerDetalle.addActionListener(this::btnVerDetalleActionPerformed);

        jButtonCambiarEstado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cambiar_estado.png"))); // NOI18N
        jButtonCambiarEstado.setText("jButton1");
        jButtonCambiarEstado.addActionListener(this::jButtonCambiarEstadoActionPerformed);

        jButtonAgregarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agregar_productos.png"))); // NOI18N
        jButtonAgregarPedido.setText("jButton1");
        jButtonAgregarPedido.addActionListener(this::jButtonAgregarPedidoActionPerformed);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Historial.png"))); // NOI18N
        jLabel2.setText("jLabel2");

        jTextBuscar.addActionListener(this::jTextBuscarActionPerformed);

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 3, 24)); // NOI18N
        jLabel3.setText("Buscar pedido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButtonAgregarPedido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, Short.MAX_VALUE)
                            .addComponent(jButtonCambiarEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(btnVerDetalle, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(1848, 1848, 1848))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(198, 198, 198)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVerDetalle, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jButtonAgregarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(jButtonCambiarEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(143, Short.MAX_VALUE))
        );

        jMenu1.setText("Inicio");
        jMenu1.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                jMenu1MenuSelected(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVerDetalleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerDetalleActionPerformed
        int fila = jTablePedidos.getSelectedRow();

    if (fila == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Selecciona un pedido de la lista para ver el detalle.", 
            "Advertencia", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    int idPedido = Integer.parseInt(jTablePedidos.getValueAt(fila, 0).toString());
    String cliente = jTablePedidos.getValueAt(fila, 2).toString();

    StringBuilder detalle = new StringBuilder();
    detalle.append("=== DETALLE DEL PEDIDO #").append(idPedido).append(" ===\n");
    detalle.append("Cliente: ").append(cliente).append("\n\n");
    detalle.append("Productos comprados:\n");
    detalle.append("-------------------------------------------\n");

    String sql = "SELECT producto, cantidad, precio_total FROM detalle_pedidos WHERE id_pedido = ?";

    try (java.sql.Connection cn = conexion.getConexion();
         java.sql.PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setInt(1, idPedido);

        try (java.sql.ResultSet rs = ps.executeQuery()) {
            boolean tieneProductos = false;

            while (rs.next()) {
                tieneProductos = true;
                String producto = rs.getString("producto");
                int cantidad = rs.getInt("cantidad");
                double precioTotal = rs.getDouble("precio_total");

                detalle.append("- ").append(producto)
                       .append(" x").append(cantidad)
                       .append("  ($").append(String.format("%.2f", precioTotal)).append(")\n");
            }

            if (!tieneProductos) {
                detalle.append("(No se encontraron productos registrados para este pedido)\n");
            }
        }

        javax.swing.JOptionPane.showMessageDialog(this, 
            detalle.toString(), 
            "Detalle del Pedido #" + idPedido, 
            javax.swing.JOptionPane.INFORMATION_MESSAGE);

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Error al consultar el detalle en MySQL: " + e.getMessage(), 
            "Error SQL", 
            javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnVerDetalleActionPerformed

    private void jButtonAgregarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarPedidoActionPerformed
        Productos ventanaProductos = new Productos();
        ventanaProductos.setLocationRelativeTo(null);
        ventanaProductos.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonAgregarPedidoActionPerformed

    private void jButtonCambiarEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCambiarEstadoActionPerformed
        int filaSeleccionada = jTablePedidos.getSelectedRow();

        if (filaSeleccionada >= 0) {
            Pedido pedidoSeleccionado = Productos.getPedidosRegistrados().get(filaSeleccionada);

            String[] estados = {"En preparación", "Preparado", "Cancelado"};

            String nuevoEstado = (String) JOptionPane.showInputDialog(
                    this,
                    "Selecciona el nuevo estado:",
                    "Cambiar estado",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    estados,
                    pedidoSeleccionado.getEstado()
            );

            if (nuevoEstado != null) {
                pedidoSeleccionado.setEstado(nuevoEstado);
                cargarPedidos(); 

                JOptionPane.showMessageDialog(this,
                        "Estado actualizado correctamente.",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "Selecciona un pedido primero.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButtonCambiarEstadoActionPerformed

    private void jMenu1MenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_jMenu1MenuSelected
        AppFS inicio = new AppFS();

        inicio.setLocationRelativeTo(null);

        inicio.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jMenu1MenuSelected

    private void jTextBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextBuscarActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new PedidosFS().setVisible(true));
    }

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVerDetalle;
    private javax.swing.JButton jButtonAgregarPedido;
    private javax.swing.JButton jButtonCambiarEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePedidos;
    private javax.swing.JTextField jTextBuscar;
    // End of variables declaration//GEN-END:variables

    private void cargarPedidos() {
        DefaultTableModel modelo = (DefaultTableModel) jTablePedidos.getModel();
    modelo.setRowCount(0); // Limpiar filas de la tabla

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    String sql = "SELECT id_pedido, fecha, cliente, total, estado FROM pedidos ORDER BY id_pedido DESC";

    try (java.sql.Connection cn = conexion.getConexion();
         java.sql.PreparedStatement ps = cn.prepareStatement(sql);
         java.sql.ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            java.sql.Timestamp timestamp = rs.getTimestamp("fecha");
            String fechaFormateada = (timestamp != null) 
                ? timestamp.toLocalDateTime().format(formatter) 
                : "";

            modelo.addRow(new Object[]{
                rs.getInt("id_pedido"),
                fechaFormateada,
                rs.getString("cliente"),
                rs.getDouble("total"),
                rs.getString("estado")
            });
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Error al cargar pedidos desde MySQL: " + e.getMessage(), 
            "Error SQL", 
            javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }

    private static class jTableDetalles {

        public jTableDetalles() {
        }
    }

}
