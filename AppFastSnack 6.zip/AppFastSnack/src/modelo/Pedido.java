/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 *
 * @author fl1pc18
 */
public class Pedido {
    private String idPedido;
    private LocalDateTime fecha;
    private String cliente;
    private Map<String, Integer> productos; // producto → cantidad
    private double total;
    private String estado;

    // Constructor
    public Pedido(String idPedido, LocalDateTime fecha, String cliente,
                  Map<String, Integer> productos, double total, String estado) {
        this.idPedido = idPedido;
        this.fecha = fecha;
        this.cliente = cliente;
        this.productos = productos;
        this.total = total;
        this.estado = estado;
    }

    // Getters
    public String getIdPedido() { return idPedido; }
    public LocalDateTime getFecha() { return fecha; }
    public String getCliente() { return cliente; }
    public Map<String, Integer> getProductos() { return productos; }
    public double getTotal() { return total; }
    public String getEstado() { return estado; }

   
    public void setEstado(String estado) { this.estado = estado; }
}