/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author USER
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;

public class CarruselFade extends JPanel {
 private ImageIcon[] imagenes = {
        new ImageIcon("src/imagenes/Promo1.png"),
        new ImageIcon("src/imagenes/Promo2.png"),
        new ImageIcon("src/imagenes/Promo3.png"),
        new ImageIcon("src/imagenes/Promo4.png")
    };
    private int indice = 0;
    private float alpha = 1.0f; // nivel de transparencia
    private Timer timerFade, timerCambio;

    public CarruselFade() {
        setPreferredSize(new Dimension(957, 147));
        setLayout(new BorderLayout());

        // Timer para el efecto de fade
        timerFade = new Timer(50, e -> {
            alpha -= 0.05f;
            if (alpha <= 0) {
                alpha = 1.0f;
                indice = (indice + 1) % imagenes.length;
            }
            repaint();
        });

        // Timer para cambiar imagen cada 5 segundos
        timerCambio = new Timer(5000, e -> timerFade.start());
        timerCambio.start();

        JButton btnAnterior = new JButton("⟨");
        btnAnterior.setPreferredSize(new Dimension(40, 40)); // cuadrado
        btnAnterior.setFont(new Font("Arial", Font.BOLD, 18));
        btnAnterior.setBackground(new Color(246, 111, 42)); // naranja FastSnack
        btnAnterior.setForeground(Color.WHITE);
        btnAnterior.setFocusPainted(false);
        btnAnterior.setBorderPainted(false);
        btnAnterior.setOpaque(true);

        btnAnterior.addActionListener(e -> {
            indice = (indice - 1 + imagenes.length) % imagenes.length;
            alpha = 1.0f;
            repaint();
        });

        // Botón cuadrado siguiente
        JButton btnSiguiente = new JButton("⟩");
        btnSiguiente.setPreferredSize(new Dimension(40, 40)); // cuadrado
        btnSiguiente.setFont(new Font("Arial", Font.BOLD, 18));
        btnSiguiente.setBackground(new Color(246, 111, 42));
        btnSiguiente.setForeground(Color.WHITE);
        btnSiguiente.setFocusPainted(false);
        btnSiguiente.setBorderPainted(false);
        btnSiguiente.setOpaque(true);

        btnSiguiente.addActionListener(e -> {
            indice = (indice + 1) % imagenes.length;
            alpha = 1.0f;
            repaint();
        });

        // Añadirlos al panel
        this.add(btnAnterior, BorderLayout.WEST);
        this.add(btnSiguiente, BorderLayout.EAST);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        g2.drawImage(imagenes[indice].getImage(), 0, 0, getWidth(), getHeight(), this);
        g2.dispose();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Carrusel con Fade");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new CarruselFade());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    }
