/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Connection;

public class PruebaConexion {

    public static void main(String[] args) {
        Connection cn = conexion.getConexion();

        if (cn != null) {
            System.out.println("¡CONEXIÓN EXITOSA CON FASTSNACK_DB!");
        } else {
            System.out.println("FALLÓ LA CONEXIÓN CON LA BASE DE DATOS.");
        }
    }
}