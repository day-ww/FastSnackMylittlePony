/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author fl1pc18
 */
abstract class Persona {
    private String nombre;
    private String telefono;

    abstract String getNombre();

    abstract void setNombre(String nombre);

    abstract String getTelefono();
    
    abstract void setTelefono(String telefono);

    public Persona(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }   
}
