/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author fl1pc18
 */
abstract class Empleado extends Persona {

    public Empleado(String nombre, String telefono) {
        super(nombre, telefono);
    }

    void accederClientes() {
        System.out.println("hola, cliente");
    }
}
