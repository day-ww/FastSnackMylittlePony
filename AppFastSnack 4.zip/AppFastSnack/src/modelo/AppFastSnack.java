/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package modelo;

/**
 *
 * @author fl1pc18
 */
public class AppFastSnack {

    public static void main(String[] args) {
        System.out.println("ola World!");
        //Clientes clientes = new Clientes("Isabella", "0997015131");
        //clientes.accederClientes();
        AppFS ventanaAppFS = new AppFS();
        
        ventanaAppFS.setLocationRelativeTo(null);
        ventanaAppFS.setVisible(true);
    }

}
