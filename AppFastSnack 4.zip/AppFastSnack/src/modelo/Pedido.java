/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.time.LocalDateTime;

/**
 *
 * @author fl1pc18
 */
public class Pedido {

    private Clientes clientes;
    private ArrayList<Producto> productos;
    private String estado;
    private LocalDateTime fecha;

    public Pedido(Clientes clientes, ArrayList<Producto> productos, String estado, LocalDateTime fecha) {
        this.clientes = clientes;
        this.productos = new ArrayList<>();
        this.estado = "Pendiente";
        this.fecha = LocalDateTime.now();
    }

    public void agregarProducto(Producto p) {
        this.productos.add(p);

    }

    public double calcularTotal() {
        double total = 0;
        return total;
    }

    public void cambiarEstado(String estado) {
        this.estado = estado;

    }

    public void mostrarPedido() {
        System.out.println("Pedido de: " + clientes.getNombre());
        System.out.println("Fecha: " + fecha);
        System.out.println("Estado: " + estado);
        System.out.println("Productos: ");
        for (Producto p : productos) {

        }
    }

    public String getEstado() {
        return estado;
    }

}
