/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author fl1pc18
 */
public class Clientes extends Persona {

    private String direccion;
    private String nombre;
    private String telefono;
    

    public Clientes(String nombre, String telefono) {
        super(nombre, telefono);
        this.direccion = direccion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    String getNombre() {
        return nombre;
      }

    @Override
    void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    String getTelefono() {
       return telefono;
    }

    @Override
    void setTelefono(String telefono) {
        System.out.println("Esto es un cliente: " + this);
        this.telefono = telefono;
    }

    void accederClientes() {
        System.out.println("Accediendo a clientes");
    }

}
