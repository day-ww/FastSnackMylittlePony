/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.util.Optional;
import modelo.Clientes;

/**
 *
 * @author fl1pc24
 */
public interface ClienteDAO {
    Optional<Clientes> findByName (String nombre) throws utilidades.DAOException;
    
    boolean existByPhone(String telefono) throws utilidades.DAOException;

}
